
#include <string>

using namespace std;

const string AppHelp =\
"-------------------------------------------- Help ---------------------------------------------\n\
--version      - Show the version of Armadillo \t\n\
--help         - Show help \t\n\
--default-size - Set the default size which is 4x4 \t\n\
--matrix-size  - Set the size of matrix. Size must be provided as second and third argument \t\n\
-----------------------------------------------------------------------------------------------\n";
